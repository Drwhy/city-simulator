# Validation de l’archive — v0.10.0

## Backend

- 63 tests automatisés sous Python 3.12, dont 9 scénarios judiciaires v0.10.0.
- Couverture fonctionnelle : personnel citoyen, classement sans suite, capacité du tribunal, peines structurées, interdiction de contact, détention et emploi, sauvegarde v10, API, WebSocket et 30 jours continus.
- Aucun dossier ne reste en audience et aucune détention expirée ne reste active après la simulation longue.

## Frontend

- 12 tests Vitest dans 5 fichiers.
- Contrôle TypeScript strict et build Vite validés.
- File d’audiences, progression des peines, tri prioritaire, fenêtres tribunal/dossier, fiche citoyen et filtre Justice compilés.

## Commandes de validation

```bash
cd backend
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q app tests
.venv/bin/pip check

cd ../frontend
npm ci
npm test -- --run
npm run build
npm audit --audit-level=high

cd ..
git diff --check
```

## Commandes Docker

```bash
docker compose build
docker compose up
```

Frontend : `http://localhost:5173` — API : `http://localhost:8000`.

## Couverture et limites de l’environnement

- Aucun collecteur de couverture Python/Vitest n’est installé ; aucun pourcentage non mesuré n’est annoncé.
- La justice est volontairement simplifiée : pas d’appel, avocat, jury ou procédure juridique exhaustive.
- Le navigateur intégré reste indisponible à cause de `helper_unknown_error` ; le rendu est validé par TypeScript/Vite mais l’inspection interactive doit être refaite localement.
