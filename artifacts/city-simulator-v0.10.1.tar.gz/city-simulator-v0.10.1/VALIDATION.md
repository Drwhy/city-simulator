# Validation de l’archive — v0.10.1

## Backend

- 70 tests automatisés sous Python 3.12, dont 7 scénarios de communication dédiés.
- Couverture fonctionnelle : quatre canaux, disponibilité téléphonique, livraison/lecture, réponses bornées, effets relationnels, API, WebSocket et sauvegarde/reprise déterministe.
- Les scénarios historiques d’économie sur 30 jours restent identiques grâce au générateur aléatoire isolé.
- Historique global plafonné à 2 000 entrées terminales ; aucune réponse ne dépasse deux niveaux.

## Frontend

- 14 tests Vitest dans 6 fichiers.
- Contrôle TypeScript strict et build Vite validés.
- Monitoring global, composition depuis la fiche citoyen, historique, indicateurs et filtre Communications compilés.

## Commandes de validation

```bash
cd backend
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q app tests
.venv/bin/pip check

cd ../frontend
npm ci
npm test -- --run
npm run build
npm audit --audit-level=high

cd ..
git diff --check
```

## Commandes Docker

```bash
docker compose build
docker compose up
```

Frontend : `http://localhost:5173` — API : `http://localhost:8000`.

## Couverture et limites de l’environnement

- Aucun collecteur de couverture Python/Vitest n’est installé ; aucun pourcentage non mesuré n’est annoncé.
- Pas de pièces jointes, appels de groupe, répondeur, spam, chiffrement ni acheminement postal incarné.
- Le navigateur intégré reste indisponible à cause de `helper_unknown_error` ; le rendu est validé par TypeScript/Vite mais l’inspection interactive doit être refaite localement.
