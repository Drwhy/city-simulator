from __future__ import annotations
import asyncio
from fastapi import WebSocket, WebSocketDisconnect
from ..simulation.service import SimulationService

async def stream_city(websocket: WebSocket, service: SimulationService, *, interval_seconds: float = 0.5) -> None:
    await websocket.accept()
    initial = True
    try:
        while True:
            payload = await service.snapshot() if initial else await service.delta()
            initial = False
            try: await websocket.send_json(payload)
            except (WebSocketDisconnect, RuntimeError, OSError): return
            await asyncio.sleep(interval_seconds)
    except WebSocketDisconnect: return
