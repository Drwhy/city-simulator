# Validation de l’archive — v0.11.0

## Backend

- 78 tests automatisés sous Python 3.12, dont 8 scénarios territoriaux v0.11.0.
- Couverture fonctionnelle : divergence des quartiers, distance aux services, incidents répétés, sécurité ressentie, opportunités criminelles, patrouilles citoyennes, API, WebSocket et sauvegarde/reprise déterministe.
- Simulation de 30 jours : historiques bornés, zones distinctes et aucune unité bloquée sans route dans un état transitoire.
- Les scénarios historiques d’économie, santé, logement, justice et communications restent verts.

## Frontend

- 16 tests Vitest dans 7 fichiers.
- Contrôle TypeScript strict et build Vite validés.
- Neuf cartes thématiques, sélection de quartier, fenêtre complète, tendances, indicateurs et filtre Quartiers compilés.

## Commandes de validation

```bash
cd backend
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q app tests
.venv/bin/pip check

cd ../frontend
npm ci
npm test -- --run
npm run build
npm audit --audit-level=high

cd ..
git diff --check
```

## Commandes Docker

```bash
docker compose build
docker compose up
```

Frontend : `http://localhost:5173` — API : `http://localhost:8000`.

## Couverture et limites de l’environnement

- Aucun collecteur de couverture Python/Vitest n’est installé ; aucun pourcentage non mesuré n’est annoncé.
- Quatre quartiers fixes, éclairage non administrable et deux patrouilles simultanées au maximum.
- Le navigateur intégré est bloqué par `helper_unknown_error` ; TypeScript/Vite valident le rendu, mais l’inspection interactive doit être refaite localement.
