# Validation de l'archive — v0.9.0

## Backend

- 54 tests automatisés sous Python 3.12 : scénarios historiques, résidentiels, métriques et persistance atomique.
- Foyer pauvre vers moins cher, foyer agrandi vers plus grand, changement de trajet, déménagement groupé, séparation, relogement, anti-boucle, sauvegarde v9 et 30 jours continus.
- API `/api/housing`, `/api/households/{id}`, bâtiments résidentiels, snapshot et delta WebSocket couverts.

## Frontend

- 9 tests Vitest couvrant les deltas WebSocket, l’URL du flux, les groupes d’indicateurs et l’état immuable des couches ; contrôle TypeScript et build Vite.
- Panneau compact par catégories, contrôles, fiche logement, fiche foyer et inspecteurs spécialisés compilés.

## Commandes

```bash
cd backend
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q app tests
.venv/bin/pip check

cd ../frontend
npm ci
npm test -- --run
npm run build
npm audit --audit-level=high

cd ..
git diff --check
```

## Couverture et limites de l’environnement

- Les suites passent intégralement, mais aucun collecteur de couverture (`coverage.py`/`pytest-cov` ou provider Vitest) n’est installé dans le projet : aucun pourcentage fiable n’est annoncé.
- Le navigateur intégré n'a pas pu charger sa compétence à cause de `helper_unknown_error`. L'inspection visuelle interactive doit être refaite localement ; TypeScript, Vite, API et WebSocket sont validés automatiquement.
