from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..simulation.service import SimulationService


class SpeedRequest(BaseModel):
    speed: int


class StepRequest(BaseModel):
    minutes: int = Field(default=1, ge=1, le=1440)


class ResetRequest(BaseModel):
    seed: int | None = None


def create_api_router(service: SimulationService) -> APIRouter:
    router = APIRouter(prefix="/api")

    @router.get("/health")
    async def health() -> dict:
        return {"status": "ok"}

    @router.get("/city")
    async def city_snapshot() -> dict:
        return await service.snapshot()

    @router.get("/healthcare")
    async def healthcare_overview() -> dict:
        return await service.health_overview()

    @router.get("/housing")
    async def housing_overview() -> dict:
        return await service.housing_overview()

    @router.get("/economy")
    async def economy_overview() -> dict:
        return await service.economy_overview()

    @router.get("/social/graph")
    async def social_graph() -> dict:
        return await service.social_graph()

    @router.get("/households/{household_id}")
    async def household_detail(household_id: int) -> dict:
        return await _detail_or_404(service.household_detail, household_id, "Foyer introuvable")

    @router.get("/citizens/{citizen_id}")
    async def citizen_detail(citizen_id: int) -> dict:
        return await _detail_or_404(service.citizen_detail, citizen_id, "Habitant introuvable")

    @router.get("/vehicles/{vehicle_id}")
    async def vehicle_detail(vehicle_id: int) -> dict:
        return await _detail_or_404(service.vehicle_detail, vehicle_id, "Véhicule introuvable")

    @router.get("/incidents/{incident_id}")
    async def incident_detail(incident_id: int) -> dict:
        return await _detail_or_404(service.incident_detail, incident_id, "Incident introuvable")

    @router.get("/buildings/{building_id}")
    async def building_detail(building_id: int) -> dict:
        return await _detail_or_404(service.building_detail, building_id, "Bâtiment introuvable")

    @router.get("/enterprises/{building_id}")
    async def enterprise_detail(building_id: int) -> dict:
        return await _detail_or_404(service.enterprise_detail, building_id, "Entreprise introuvable")

    @router.get("/investigations/{investigation_id}")
    async def investigation_detail(investigation_id: int) -> dict:
        return await _detail_or_404(service.investigation_detail, investigation_id, "Enquête introuvable")

    @router.get("/cases/{case_id}")
    async def case_detail(case_id: int) -> dict:
        return await _detail_or_404(service.case_detail, case_id, "Dossier judiciaire introuvable")

    @router.post("/simulation/pause")
    async def pause() -> dict:
        await service.set_paused(True)
        return {"paused": True}

    @router.post("/simulation/resume")
    async def resume() -> dict:
        await service.set_paused(False)
        return {"paused": False}

    @router.post("/simulation/speed")
    async def set_speed(request: SpeedRequest) -> dict:
        try:
            await service.set_speed(request.speed)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return {"speed": request.speed}

    @router.post("/simulation/step")
    async def step(request: StepRequest) -> dict:
        try:
            await service.step(request.minutes)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return await service.snapshot()

    @router.post("/city/save")
    async def save_city() -> dict:
        path = await service.save()
        return {"saved": True, "path": str(path)}

    @router.post("/city/load")
    async def load_city() -> dict:
        try:
            await service.load()
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except (ValueError, KeyError, TypeError) as exc:
            raise HTTPException(status_code=422, detail="Sauvegarde invalide") from exc
        return await service.snapshot()

    @router.post("/city/reset")
    async def reset(request: ResetRequest) -> dict:
        await service.reset(seed=request.seed)
        return await service.snapshot()

    return router


async def _detail_or_404(loader, object_id: int, message: str) -> dict:
    try:
        return await loader(object_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=message) from exc